#include "GPIO_dyn_conf.h" 


int Num_Broche = 8;
//=======================================================================================
int main(void)
{
	char flipflop = 1;
	Port_IO_Init();

	while(1)
	{
			if (flipflop=!flipflop)
			{
				PORT_IO_CLR(GPIOB,Num_Broche);
			}
			else
			{
				PORT_IO_SET(GPIOB,Num_Broche);
			}
	}
	
}

