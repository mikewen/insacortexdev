// By default all pins are floating input and their
// port clock bridge may not be switched on
//
// To ensure a port clock bridge to be on, uncomment the
// #define GPIO?_USED lines
//
// Then to change pin configuration add lines in the format 
//
//#undef P_<port>_<pin_number>
//#define P_<port>_<pin_number> <pin_mode>
//
// <port> is either A,B,C or D
// <pin_number> from 0 to 15
// <pin_mode> can be for output pins
//     IS_OUTPUT_PUSH_PULL
//     IS_OUTPUT_OPEN_DRAIN
//
// For example to configure PIN 3 of port GPIOA :

// CONF uncomment the following line
// to enable GPIOA clock bridge
//#define GPIOA_USED
// CONF then add pins configuration list if not floating input 

// CONF uncomment the following line
// to enable GPIOB clock bridge
#define GPIOB_USED
// CONF then add pins configuration list if not floating input 
#undef P_B_8
#define P_B_8 IS_GENERAL_OUTPUT_PUSHPULL_10MHZ
#undef P_B_9
#define P_B_9 IS_GENERAL_OUTPUT_PUSHPULL_10MHZ

// CONF uncomment the following line
// to enable GPIOC clock bridge
//#define GPIOC_USED
// CONF then add pins configuration list if not floating input 

// CONF uncomment the following line
// to enable GPIOD clock bridge
//#define GPIOD_USED
// CONF then add pins configuration list if not floating input 
				